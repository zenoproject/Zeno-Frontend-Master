//DashBoard Data

export const KPI_CARD_TOP_SECTION = [
  {
    header: 'Users enrolled',
    count: 16,
  },
  {
    header: "Do's scheduled",
    count: 3,
  },
  {
    header: "Do's sent",
    count: 6,
  },
  {
    header: "Do's completed",
    count: 7,
  },
];

export const KPI_CARD_BOTTOM_SECTION = [
  {
    header: 'Title',
    data: 'ToDo-RCT',
  },
  {
    header: 'Duration',
    data: '24 Weeks',
  },
  {
    header: 'Starts',
    data: '15-10-2021',
  },
  {
    header: 'Ends',
    data: '16-10-2021',
  },
  {
    header: 'Users',
    data: 74,
  },
];

export const LINE_GRAPH_DATA = [
  {
    date: '2021-02-12T18:30:00.000Z',
    visits: 1605,
    views: 8707,
  },
  {
    date: '2021-02-13T18:30:00.000Z',
    visits: 1596,
    views: 8700,
  },
  {
    date: '2021-02-14T18:30:00.000Z',
    visits: 1593,
    views: 8701,
  },
  {
    date: '2021-02-15T18:30:00.000Z',
    visits: 1587,
    views: 8696,
  },
  {
    date: '2021-02-16T18:30:00.000Z',
    visits: 1591,
    views: 8704,
  },
  {
    date: '2021-02-17T18:30:00.000Z',
    visits: 1586,
    views: 8710,
  },
  {
    date: '2021-02-18T18:30:00.000Z',
    visits: 1579,
    views: 8719,
  },
  {
    date: '2021-02-19T18:30:00.000Z',
    visits: 1573,
    views: 8712,
  },
  {
    date: '2021-02-20T18:30:00.000Z',
    visits: 1568,
    views: 8718,
  },
  {
    date: '2021-02-21T18:30:00.000Z',
    visits: 1565,
    views: 8722,
  },
  {
    date: '2021-02-22T18:30:00.000Z',
    visits: 1562,
    views: 8730,
  },
  {
    date: '2021-02-23T18:30:00.000Z',
    visits: 1567,
    views: 8736,
  },
  {
    date: '2021-02-24T18:30:00.000Z',
    visits: 1559,
    views: 8742,
  },
  {
    date: '2021-02-25T18:30:00.000Z',
    visits: 1567,
    views: 8742,
  },
  {
    date: '2021-02-26T18:30:00.000Z',
    visits: 1564,
    views: 8733,
  },
];
