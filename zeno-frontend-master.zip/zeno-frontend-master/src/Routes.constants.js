export const ROUTES = {
  LOGIN: '/login',
  INDEX: '/',
  HOME: '/dashboard',
  SCHEDULE: '/schedule',
  CHANGE_PASSWORD: '/changePassword/',
  REPOSITORIES: '/repositories',
  OVERVIEW: '/overview',
};
