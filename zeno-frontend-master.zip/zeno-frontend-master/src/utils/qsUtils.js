import qs from 'qs';
import CONSTANTS from '../Components/Sidebar/Sidebar.constants';

export const parseWebUrl = (search = window.location.search) => {
  search = search.substr(1);
  return qs.parse(search);
};

export const makeWebUrl = (json) => {
  return '?' + qs.stringify(json);
};

export const getInitialRoute = (isAdmin = false) => {
  if (!isAdmin) {
    return CONSTANTS.navItems[1].path;
  } else {
    return CONSTANTS.navItems[0].path;
  }
};
