import moment from 'moment';

export const getShortDate = (date) => {
  return moment(date).format('yyyy-MM-DD');
};

export const getDisplayDate = (date) => {
  return moment(date).format('DD MMM yyyy');
};

export const getDisplayTime = (date) => {
  return moment(date).format('HH:MM a');
};
