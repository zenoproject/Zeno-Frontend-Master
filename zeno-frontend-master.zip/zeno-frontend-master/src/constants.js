// Login heading
export const HEADINGS = {
  COUNTER: 'Counter',
  LOGIN_HERE: 'Login Here',
  SIGN_UP: 'Sign Up',
};
