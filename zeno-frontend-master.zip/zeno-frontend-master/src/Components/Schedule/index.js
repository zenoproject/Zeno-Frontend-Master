/*eslint-disable*/
import React from 'react';
import { Calendar, Badge } from 'antd';
import { getShortDate } from '../../utils/TimeDateUtils';

function getListData(value) {
  let listData = [
    { date: '2021-05-01', type: 'warning', content: 'This is warning event.' },
    { date: '2021-05-02', type: 'success', content: 'This is usual event.' },
    { date: '2021-05-03', type: 'warning', content: 'This is warning event.' },
    { date: '2021-05-04', type: 'success', content: 'This is usual event.' },
    { date: '2021-05-05', type: 'error', content: 'This is error event.' },
    { date: '2021-05-06', type: 'warning', content: 'This is warning event' },
    {
      date: '2021-05-07',
      type: 'success',
      content: 'This is very long usual event。。....',
    },
    { date: '2021-05-08', type: 'error', content: 'This is error event 1.' },
    { date: '2021-05-09', type: 'error', content: 'This is error event 2.' },
    { date: '2021-05-10', type: 'error', content: 'This is error event 3.' },
    { date: '2021-05-11', type: 'error', content: 'This is error event 4.' },
  ];

  return listData || [];
}

function dateCellRender(value) {
  const listData = getListData();
  return (
    <ul className='events'>
      {listData.map((item) => (
        <li key={item.content}>
          {getShortDate(value) === item.date && (
            <Badge status={item.type} text={item.content} />
          )}
        </li>
      ))}
    </ul>
  );
}

function getMonthData(value) {
  if (value.month() === 8) {
    return 1394;
  }
}

function monthCellRender(value) {
  const num = getMonthData(value);
  return num ? (
    <div className='notes-month'>
      <section>{num}</section>
      <span>Backlog number</span>
    </div>
  ) : null;
}

export default function Schedule(props) {
  return (
    <Calendar
      dateCellRender={dateCellRender}
      monthCellRender={monthCellRender}
    />
  );
}
