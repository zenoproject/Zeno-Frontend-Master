import React from 'react';
import constants from './Sidebar.constants';
import { Link } from 'react-router-dom';
import style from './style.module.scss';
import SVGIcons from '../SVGIcons';
import { getInitialRoute } from '../../utils/qsUtils';
import { GetLocalStorage } from '../../utils/localStorageOperations';
import ProgressBar from '../ProgressBar';
function Sidebar(props) {
  //stop link click action in same page
  const onClick = (e) =>
    window.location.pathname === getInitialRoute() && e.preventDefault();
  return (
    <div className={style.asideBlock}>
      <div className={style.brandLogo}>
        <Link
          className={style.brandLink}
          to={getInitialRoute()}
          onClick={onClick}
        >
          <span>
            <SVGIcons type='SVG-brandlogo' />
          </span>
          <span>LOGO</span>
        </Link>
      </div>
      <h5>ZENO DASHBOARD</h5>
      <ul
        className={style.asideMenu}
        children={constants.navItems.map((el) => tabItem(el, props))}
      />
      <ul className={style.projectStatus}>{projectStatus()}</ul>
    </div>
  );
}

function projectStatus() {
  return (
    <>
      <li>
        <span>PROJECT STATUS</span>
      </li>
      <li>
        <span>DAYS PAST</span>
        <span>
          <ProgressBar percent={52} showInfo={false} />
        </span>
        <span>15-01-2020 t0 15-01-2022</span>
      </li>
      <li>
        <span>PARTICIPANTS INCLUDED</span>
        <span>
          <ProgressBar percent={21} showInfo={false} />
        </span>
        <span>29 out 100</span>
      </li>
      <li>
        <span>DO'S COMPLETED</span>
        <span>
          <ProgressBar percent={40} showInfo={false} />
        </span>
        <span>400 out of 1000</span>
      </li>
      <li>
        <span>
          {/* <SVGIcons type='SVG-circle-red' /> {' SEVER ERROR'} */}
          <SVGIcons type='SVG-circle-green' /> {' SEVER OK'}
        </span>
      </li>
    </>
  );
}

function tabItem(el, props) {
  if (el.forAdmin) {
    if (GetLocalStorage('isAdmin')) {
      return (
        <li className={getTabItemClass(el.path)} key={el.path}>
          {renderTab(el, props)}
        </li>
      );
    }
  } else {
    return (
      <li className={getTabItemClass(el.path)} key={el.path}>
        {renderTab(el, props)}
      </li>
    );
  }
}

function getTabItemClass(path) {
  const isActive = isActiveRoute(path);
  return isActive ? style.active : '';
}

function isActiveRoute(route) {
  return window.location.pathname.startsWith(route);
}

function getAtagClass(el) {
  return (
    <>
      {el.svgType && (
        <span className={style.menuIcon}>
          <SVGIcons type={el.svgType} />
        </span>
      )}
      <span children={el.label} />
    </>
  );
}

function renderTab(el, { history, location }) {
  const onClick = () => {
    if (window.location.pathname !== el.path) history.push(el.path);
  };
  return <a onClick={onClick}>{getAtagClass(el)}</a>;
}

export default Sidebar;
