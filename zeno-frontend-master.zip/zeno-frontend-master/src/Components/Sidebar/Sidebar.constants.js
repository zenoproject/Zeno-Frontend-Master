import { ROUTES } from '../../Routes.constants';

const CONSTANTS = {
  navItems: [
    {
      label: 'Dashboard',
      svgType: 'SVG-dashboard',
      path: ROUTES.HOME,
    },
    {
      label: 'USERS',
    },
    {
      label: 'Status',
      svgType: 'SVG-user',
      //path: ROUTES.HOME,
    },
    {
      label: 'Score',
      svgType: 'SVG-rules',
      //path: ROUTES.HOME,
    },
    {
      label: 'Schedule',
      svgType: 'SVG-dashboard',
      path: ROUTES.SCHEDULE,
    },
    {
      label: 'PROGRAMME',
    },
    {
      label: 'Overview',
      svgType: 'SVG-user',
      path: ROUTES.OVERVIEW,
    },
    {
      label: 'Repository',
      svgType: 'SVG-rules',
      //path: ROUTES.HOME,
    },
    {
      label: 'Input',
      svgType: 'SVG-rules',
      //path: ROUTES.HOME,
    },
  ],
};

export default CONSTANTS;
