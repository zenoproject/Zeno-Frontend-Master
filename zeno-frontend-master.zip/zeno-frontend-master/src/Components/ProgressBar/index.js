import React from 'react';
import { Progress } from 'antd';

export default function ProgressBar(props) {
  const renderComponentProps = () => {
    let progressObject = {};
    progressObject.type = props.type;
    progressObject.percent = props.percent;
    progressObject.showInfo = props.showInfo;
    progressObject.strokeColor = '#ff0000';
    if (props.percent >= 26 && props.percent < 49) {
      progressObject.strokeColor = '#FFFF00';
    } else if (props.percent >= 50 && props.percent < 74) {
      progressObject.strokeColor = '#0026ff';
    } else if (props.percent >= 75) {
      progressObject.strokeColor = '#5e8f46';
    }
    return progressObject;
  };
  return <Progress {...renderComponentProps()} />;
}
