import React from 'react';
import Pagination from '../Pagination';
import { withRouter } from 'react-router';
import { parseWebUrl, makeWebUrl } from '../../utils/qsUtils';
class ListWrapper extends React.Component {
  constructor(props) {
    super(props);
    this.state = { offset: 0, limit: 0 };
  }
  componentWillMount() {
    const { notEqual, params } = this.getDefaultOffsetLimit();
    this.setState({ offset: params.offset, limit: params.limit });
    if (notEqual) this.props.history.replace({ search: makeWebUrl(params) });
    else this.props.fetchData();
  }
  componentDidUpdate = (prevProps) => {
    if (this.props.location !== prevProps.location) {
      const {
        params: { limit, offset },
      } = this.getDefaultOffsetLimit();
      this.setState({ limit, offset });
      this.props.fetchData();
    }
  };
  getDefaultOffsetLimit = () => {
    let params = parseWebUrl();
    let { limit, offset } = params;
    let notEqual;
    if (limit === undefined || offset === undefined) {
      params = { ...params, ...(this.props.defaultParams || {}) };
      notEqual = true;
    }
    return { notEqual, params };
  };
  onPageChange = (current, limit) => {
    const items = parseWebUrl();
    const offset = current * limit - limit;
    this.setState({ limit, offset });
    this.props.history.push({
      search: makeWebUrl({ ...items, offset, limit }),
    });
  };
  renderPagination = () => {
    const { limit, offset } = this.state;
    if (this.props.total <= limit) return '';
    const current = Math.floor(
      (parseInt(limit) + parseInt(offset)) / parseInt(limit)
    );
    return (
      <Pagination
        onChange={this.onPageChange}
        current={current}
        pageSize={parseInt(limit)}
        total={parseInt(this.props.total)}
      />
    );
  };
  render() {
    if (this.props.api.loading) return this.props.loader || '';
    if (this.props.api.error) return this.props.error || '';
    if (!this.props.list.length) return this.props.empty || '';
    return (
      <React.Fragment>
        {this.props.children}
        {this.renderPagination()}
      </React.Fragment>
    );
  }
}
export default withRouter(ListWrapper);
