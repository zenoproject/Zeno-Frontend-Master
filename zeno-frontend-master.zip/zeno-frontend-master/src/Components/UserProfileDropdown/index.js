/* eslint-disable */
import React, { Component } from 'react';
import { Link, withRouter } from 'react-router-dom';
import {
  ClearLocalStorage,
  GetLocalStorage,
} from '../../utils/localStorageOperations';
import style from './style.module.scss';
import { ROUTES } from '../../Routes.constants';
import ModalWindow from '../ModalWindow';
import { ButtonElement } from '../ButtonElement';

class UserProfileDropdown extends Component {
  constructor(props) {
    super(props);
    this.state = {
      visible: false,
    };
  }
  onCancelLogout = () => {
    this.setState({ visible: !this.state.visible });
  };

  onLogout = () => {
    ClearLocalStorage();
    this.props.history.push(ROUTES.INDEX);
  };

  footer = () => {
    return (
      <>
        <ButtonElement
          type='primary'
          children='No'
          onClick={() => this.onCancelLogout()}
        />
        <ButtonElement type='' children='Yes' onClick={() => this.onLogout()} />
      </>
    );
  };
  render() {
    return (
      <>
        <div className={style.profileBlock}>
          <div className={style.profileBlock__image}>
            <span>
              <img src='/img/avatar.png' alt='logo' />
            </span>
            <span className={style.editOverlay}>edit</span>
          </div>
          <h3 className={style.profileBlock__name}>
            {GetLocalStorage('username')}
          </h3>
        </div>
        <ul className={style.userProfile}>
          <li
            onClick={() => {
              this.setState({
                visible: true,
              });
            }}
          >
            <Link
              className={style.logoutPane}
              onClick={() => {
                this.setState({ visible: true });
              }}
            >
              <span>
                <svg viewBox='0 0 226.529 249.963'>
                  <path
                    data-name='Path 264'
                    d='M90.438,247.662a112.639,112.639,0,0,1-40.5-17.043A113.6,113.6,0,0,1,8.9,180.786a112.723,112.723,0,0,1-6.6-21.261,114.357,114.357,0,0,1,0-45.654,112.636,112.636,0,0,1,17.042-40.5A113.6,113.6,0,0,1,69.177,32.335c1.5-.636,3.042-1.247,4.576-1.818a14.6,14.6,0,0,1,5.3,1.366,9.086,9.086,0,0,1,4.493,4.643c0-.005,0-.008,0-.009s.005.005.015.025a9.831,9.831,0,0,1,.626,3.442,14.035,14.035,0,0,1-.34,3.438,16.38,16.38,0,0,1-1.59,4.2c-1.916.667-3.832,1.4-5.695,2.192a94.17,94.17,0,1,0,73.407,0c-.843-.357-1.7-.706-2.559-1.038a11.954,11.954,0,0,1-2.689-5.124,10.888,10.888,0,0,1,.926-7.126,14.28,14.28,0,0,1,8.234-5.593c1.162.446,2.33.917,3.471,1.4A113.3,113.3,0,0,1,90.438,247.662ZM103.222,93.736V10.043a10.043,10.043,0,1,1,20.086,0V93.736a10.043,10.043,0,1,1-20.086,0Z'
                  />
                </svg>
              </span>
              <span>Logout</span>
            </Link>
          </li>
        </ul>
        <ModalWindow
          title='Heads Up!'
          width={50}
          visible={this.state.visible}
          onCancel={this.onCancelLogout}
          footer={this.footer()}
        >
          <span>Are you sure you want to Logout.?</span>
        </ModalWindow>
      </>
    );
  }
}
export default withRouter(UserProfileDropdown);
