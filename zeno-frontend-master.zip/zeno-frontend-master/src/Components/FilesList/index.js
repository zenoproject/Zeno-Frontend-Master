import React from 'react';

export default class FileList extends React.Component {
  render() {
    return <h2>File List</h2>;
  }
}
