export const LOCAL_OVERWRITE = {
  items_per_page: '',
  jump_to: '',
  jump_to_confirm: '',
  page: '',
  prev_page: 'Previous',
  next_page: 'Next',
  prev_5: '',
  next_5: '',
  prev_3: '',
  next_3: '',
};
