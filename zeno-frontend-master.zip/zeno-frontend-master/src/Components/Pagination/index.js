import React from 'react';
import Paginate from 'rc-pagination';
import 'rc-pagination/assets/index.css';
import PropTypes from 'prop-types';
import { LOCAL_OVERWRITE } from './Pagination.Constants';
import './style.scss';
const Pagination = (props) => {
  return (
    <div className='pagination-block'>
      <Paginate
        current={props.current}
        total={props.total}
        pageSize={props.pageSize}
        onChange={props.onChange}
        locale={LOCAL_OVERWRITE}
        showLessItems={true}
      />
    </div>
  );
};
Pagination.propTypes = {
  pageCount: PropTypes.number,
  onPageChange: PropTypes.func,
  initialPage: PropTypes.number,
};
export default Pagination;
