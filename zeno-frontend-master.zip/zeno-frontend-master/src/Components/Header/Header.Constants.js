import { ROUTES } from '../../Routes.constants';

export const GetHeaderSubtitles = ({ headerPath }) => {
  if (HeaderSubtitles[headerPath]?.subTitle) {
    return HeaderSubtitles[headerPath].subTitle;
  } else {
    return '';
  }
};

export const GetHeaderTitles = ({ headerPath }) => {
  if (HeaderSubtitles[headerPath]?.title) {
    return HeaderSubtitles[headerPath].title;
  } else {
    return '';
  }
};

const HeaderSubtitles = {
  [ROUTES.HOME]: {
    title: 'Dashboard',
    subTitle: 'Home',
  },
  [ROUTES.SCHEDULE]: {
    title: 'Users',
    subTitle: 'Schedule',
  },
  [ROUTES.OVERVIEW]: {
    title: 'Programme',
    subTitle: 'Overview',
  },
};
