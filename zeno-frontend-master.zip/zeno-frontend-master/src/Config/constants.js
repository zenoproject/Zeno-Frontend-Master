export const API_BASE_URL = 'http://localhost:5000';

export const LOGIN_ROUTE = '/api/user/login';
export const USER_REGISTER = '/api/user/register';
export const CHANGE_PASSWORD_ROUTE = '/api/users/updatepassword';
