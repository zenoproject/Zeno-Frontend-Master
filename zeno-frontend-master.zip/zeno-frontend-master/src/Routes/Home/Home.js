import React, { Component } from 'react';
import globel from '../../styles/globel/style.module.scss';
import style from './style.module.scss';
import { EmptyState } from '../../Components/EmptyState';
import LineGraphSection from './Children/LineGraph';
import * as constants from './constants';
import KpiCard from './Children/KPICards';
import FooterKpiCard from './Children/DashBoradFooter';

export default class Home extends Component {
  render() {
    return (
      <>
        <article className={globel.contentBlock}>
          <KpiCard />
          <LineGraphSection data={constants.DUMMY_DATA} />
          <FooterKpiCard />
        </article>
      </>
    );
  }
}
