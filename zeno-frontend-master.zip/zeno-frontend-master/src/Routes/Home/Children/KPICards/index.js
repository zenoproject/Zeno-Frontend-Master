import React, { Component } from 'react';
import {
  Card,
  CardBody,
  CardFooter,
  CardHeader,
} from '../../../../Components/Card';
import style from './style.module.scss';
import { Col, Row } from 'antd';
const DUMMY_DATA = [
  {
    header: 'Users enrolled',
    count: 16,
    cardClassName: `${style.cardFirst}`,
    cardHeaderClassName: `${style.cardFirstHeader}`,
    cardBodyClassName: `${style.cardFirstBody}`,
  },
  {
    header: "Do's scheduled",
    count: 3,
    cardClassName: `${style.cardSecond}`,
    cardHeaderClassName: `${style.cardSecondHeader}`,
    cardBodyClassName: `${style.cardSecondBody}`,
  },
  {
    header: "Do's sent",
    count: 6,
    cardClassName: `${style.cardThird}`,
    cardHeaderClassName: `${style.cardThirdHeader}`,
    cardBodyClassName: `${style.cardThirdBody}`,
  },
  {
    header: "Do's completed",
    count: 7,
    cardClassName: `${style.cardFourth}`,
    cardHeaderClassName: `${style.cardFourthHeader}`,
    cardBodyClassName: `${style.cardFourthBody}`,
  },
];
export default class KpiCard extends Component {
  renderCardComponent = () => {
    return (
      <>
        {DUMMY_DATA.map((item, index) => {
          return (
            <Col xs={24} sm={24} md={8} lg={8} xl={6} xxl={4}>
              <Card className={item.cardClassName}>
                <CardHeader className={item.cardHeaderClassName}>
                  <h3>{item.count}</h3>
                </CardHeader>
                <CardBody className={item.cardBodyClassName}>
                  {item.header}
                </CardBody>
              </Card>
            </Col>
          );
        })}
      </>
    );
  };
  render() {
    return (
      <div>
        <Row gutter={16}> {this.renderCardComponent()}</Row>
      </div>
    );
  }
}
