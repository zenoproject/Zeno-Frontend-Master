import React, { Component } from 'react';
import LineGraph from '../../../../Components/Chart';
import {
  Card,
  CardBody,
  CardFooter,
  CardHeader,
} from '../../../../Components/Card';
export default class LineGraphSection extends Component {
  render() {
    return (
      <>
        <Card>
          <CardHeader>
            <span>
              <h3>User Enrollment</h3>
              <span>From 19 April 2021 unit 18 May 2021s</span>
            </span>
          </CardHeader>
          <CardBody>
            <LineGraph
              data={this.props.data}
              firstValue={{ label: 'Users Enrolled', value: 'visits' }}
              secondValue={{ label: 'Users Completed', value: 'views' }}
            />
          </CardBody>
        </Card>
      </>
    );
  }
}
