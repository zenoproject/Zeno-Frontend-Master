import React, { Component } from 'react';
import {
  Card,
  CardBody,
  CardFooter,
  CardHeader,
} from '../../../../Components/Card';
import style from './style.module.scss';
const DUMMY_DATA = [
  {
    header: 'Title',
    data: 'ToDo-RCT',
    cardClassName: `${style.cardFirst}`,
    cardHeaderClassName: `${style.cardFirstHeader}`,
    cardBodyClassName: `${style.cardFirstBody}`,
  },
  {
    header: 'Duration',
    data: '24 Weeks',
    cardClassName: `${style.cardSecond}`,
    cardHeaderClassName: `${style.cardSecondHeader}`,
    cardBodyClassName: `${style.cardSecondBody}`,
  },
  {
    header: 'Starts',
    data: '15-10-2021',
    cardClassName: `${style.cardThird}`,
    cardHeaderClassName: `${style.cardThirdHeader}`,
    cardBodyClassName: `${style.cardThirdBody}`,
  },
  {
    header: 'Ends',
    data: '16-10-2021',
    cardClassName: `${style.cardFourth}`,
    cardHeaderClassName: `${style.cardFourthHeader}`,
    cardBodyClassName: `${style.cardFourthBody}`,
  },
  {
    header: 'Users',
    data: 74,
    cardClassName: `${style.cardFifth}`,
    cardHeaderClassName: `${style.cardFifthHeader}`,
    cardBodyClassName: `${style.cardFifthBody}`,
  },
];
export default class FooterKpiCard extends Component {
  renderCardComponent = () => {
    return (
      <>
        {DUMMY_DATA.map((item, index) => {
          return (
            <div className={`${style.col}`}>
              <Card className={item.cardClassName}>
                <CardHeader className={item.cardHeaderClassName}></CardHeader>
                <CardBody className={item.cardBodyClassName}>
                  {item.header}
                  <h3>{item.data}</h3>
                </CardBody>
              </Card>
            </div>
          );
        })}
      </>
    );
  };
  render() {
    return (
      <Card>
        <CardHeader>Programme Info</CardHeader>
        <CardBody>
          <div className={`${style.colContainer}`}>
            {this.renderCardComponent()}
          </div>
        </CardBody>
      </Card>
    );
  }
}
