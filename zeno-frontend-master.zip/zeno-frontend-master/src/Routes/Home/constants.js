/*eslint-disable*/
export const DUMMY_DATA = [
  {
    date: "2021-02-12T18:30:00.000Z",
    visits: 16.05,
    views: 7.707,
  },
  {
    date: "2021-02-13T18:30:00.000Z",
    visits: 15.96,
    views: 7.7,
  },
  {
    date: "2021-02-14T18:30:00.000Z",
    visits: 15.93,
    views: 7.701,
  },
  {
    date: "2021-02-15T18:30:00.000Z",
    visits: 15.87,
    views: 7.696,
  },
  {
    date: "2021-02-16T18:30:00.000Z",
    visits: 15.91,
    views: 7.704,
  },
  {
    date: "2021-02-17T18:30:00.000Z",
    visits: 15.86,
    views: 7.71,
  },
  {
    date: "2021-02-18T18:30:00.000Z",
    visits: 15.79,
    views: 7.719,
  },
  {
    date: "2021-02-19T18:30:00.000Z",
    visits: 15.73,
    views: 7.712,
  },
  {
    date: "2021-02-20T18:30:00.000Z",
    visits: 15.68,
    views: 7.718,
  },
  {
    date: "2021-02-21T18:30:00.000Z",
    visits: 15.65,
    views: 7.722,
  },
  {
    date: "2021-02-22T18:30:00.000Z",
    visits: 15.62,
    views: 7.73,
  },
  {
    date: "2021-02-23T18:30:00.000Z",
    visits: 15.67,
    views: 7.736,
  },
  {
    date: "2021-02-24T18:30:00.000Z",
    visits: 15.59,
    views: 7.742,
  },
  {
    date: "2021-02-25T18:30:00.000Z",
    visits: 15.67,
    views: 7.742,
  },
  {
    date: "2021-02-26T18:30:00.000Z",
    visits: 15.64,
    views: 7.733,
  },
];
