import React, { Component } from 'react';
import Schedule from '../../Components/Schedule';
import { Card, CardBody, CardFooter, CardHeader } from '../../Components/Card';
import FormBlock from '../../Components/FormBlock';
export default class Scedule extends Component {
  constructor(props) {
    super(props);
    this.state = {
      userList: [
        { value: 'user1', label: 'Jack Danel' },
        { value: 'user2', label: 'John' },
        { value: 'user3', label: 'Sammual' },
      ],
    };
  }
  render() {
    return (
      <>
        <Card>
          <CardHeader>
            <span>
              <h3>Programme Scedule</h3>
              <span>Select or Search for a user</span>
            </span>
            <div style={{ minWidth: '200px' }}>
              <FormBlock
                placeholder={'Select or Search for a user'}
                elementType='select'
                optionList={this.state.userList}
              />
            </div>
          </CardHeader>
          <CardBody>
            <Schedule />
          </CardBody>
        </Card>
      </>
    );
  }
}
