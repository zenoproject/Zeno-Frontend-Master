/*eslint-disable*/
import React, { Component } from "react";
import LoginForm from "./Children/LoginForm";
import SignUpForm from "./Children/SignUpForm";
import ChangePassword from "./Children/ChangePassword";
import { ROUTES } from "../../Routes.constants";
import { HEADINGS } from "./constants";
import PropType from "prop-types";
import style from "./style.module.scss";
import { Route, Switch, withRouter } from "react-router";
import { parseWebUrl } from "../../utils/qsUtils";
import { ButtonElement } from "../../Components/ButtonElement";
class LoginPage extends Component {
  constructor(props) {
    super(props);
    this.state = { showLogin: true, signUp: false, welcomePage: false };
  }
  inputChange = (e) => {
    this.setState({ loginCredChanges: true });
    this.props.inputFormChange(e);
  };
  handleSubmit = (e) => {
    e.preventDefault();
    this.props.login(
      {
        email: this.props.email.value,
        password: this.props.password.value,
      },
      // Change this to handle change password
      ({ newPasswordRequired, email }) => {
        newPasswordRequired
          ? this.props.history.push({
              pathname: ROUTES.CHANGE_PASSWORD,
              search: `?email=${email}`,
            })
          : this.props.history.push(ROUTES.HOME);
      },
      this.props.dummyUsers
    );
  };
  handleChangePassword = (e) => {
    e.preventDefault();
    this.props.changePassword({
      username: parseWebUrl().email,
      newPassword: this.props.newPassword.value,
      confirmNewPassword: this.props.confirmNewPassword.value,
    });
  };
  renderLoading = () => {
    return <div>Loading...</div>;
  };
  showSignUp = () => {
    this.setState({ showLogin: false, signUp: true });
  };
  showLogin = () => {
    this.setState({ showLogin: true, signUp: false });
  };

  showWelcome = () => {
    if (!this.props.signUpApi.error) {
      this.setState({ welcomePage: true, signUp: false, showLogin: false });
    }
  };

  signUpInputChange = (e) => {
    this.props.signUpFormChange(e);
  };

  componentDidUpdate = () => {
    if (this.props.signUpApi.success && this.state.signUp) {
      this.showWelcome();
      this.props.resetSignUp();
    }
  };
  componentWillUnmount = () => {
    let resetObj = { name: "reset", value: true };
    this.props.inputFormChange(resetObj);
  };
  handleSignUp = (e) => {
    e.preventDefault();
    this.props.signUp(
      {
        username: this.props?.signUpemail?.value,
        newPassword: this.props?.signUpNewPassword?.value,
        confirmNewPassword: this.props?.signUpConfirmPassword?.value,
      },
      // Change this to handle change password
      ({ newPasswordRequired, email }) => {
        newPasswordRequired
          ? this.props.history.push({
              pathname: ROUTES.CHANGE_PASSWORD,
              search: `?email=${email}`,
            })
          : this.props.history.push(ROUTES.HOME);
      }
    );
  };

  redirectToLogin = () => {
    this.props.history.push(ROUTES.HOME);
  };
  renderForm = () => {
    return (
      <div className={style.loginBlock}>
        <div className={style.loginBlock__content}>
          <div className={style.contentInner}>
            <div className={style.logiredirectToLoginnLogo}></div>
          </div>
        </div>
        <div className={style.loginBlock__forms}>
          <div className={style.formsElements}>
            <ul className={style.formsElements__list}>
              <Switch>
                <Route path={ROUTES.CHANGE_PASSWORD}>
                  <ChangePassword
                    {...this.props}
                    inputChange={this.inputChange}
                    handleSubmit={this.handleChangePassword}
                  />
                </Route>
                <Route path={ROUTES.LOGIN}>
                  {this.state.showLogin ? (
                    <LoginForm
                      {...this.props}
                      inputChange={this.inputChange}
                      handleSubmit={this.handleSubmit}
                    />
                  ) : (
                    <SignUpForm
                      {...this.props}
                      inputChange={this.signUpInputChange}
                      handleSubmit={this.handleSignUp}
                    />
                  )}
                  <div style={{ paddingLeft: "50px" }}>
                    {this.state.showLogin
                      ? "Don't have an account? "
                      : "Already't have an account? "}
                    <a
                      onClick={
                        this.state.showLogin ? this.showSignUp : this.showLogin
                      }
                    >
                      {this.state.showLogin ? HEADINGS.SIGN_UP : HEADINGS.LOGIN}
                    </a>
                  </div>
                </Route>
              </Switch>
            </ul>
          </div>
        </div>
      </div>
    );
  };
  ////////////////////////////////////////////////////
  renderWelcomePage = () => {
    return (
      <div className={style.welcomewrapper}>
        <div className={style.welcomewrapper__forms}>
          <div>
            <ul>
              <h3>welcome</h3>
              <a onClick={this.redirectToLogin}>
                <h3>{"Continue to dashboard >> "}</h3>
              </a>
            </ul>
          </div>
        </div>
      </div>
    );
  };
  ////////////////////////////////////////////

  renderPage = () => {
    return (
      <>
        {this.state.welcomePage ? this.renderWelcomePage() : this.renderForm()}
      </>
    );
  };
  render() {
    return (
      <section className={style.loginWrapper}>{this.renderPage()}</section>
    );
  }
}

export default withRouter(LoginPage);

LoginPage.PropType = {
  className: PropType.string,
  value: PropType.string,
  emailError: PropType.string,
  type: PropType.string,
};
