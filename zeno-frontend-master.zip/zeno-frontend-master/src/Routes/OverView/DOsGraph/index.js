/*eslint-disable*/
import React, { Component } from 'react';
import LineGraph from '../../../Components/Chart';
import FormBlock from '../../../Components/FormBlock';
import {
  Card,
  CardBody,
  CardFooter,
  CardHeader,
} from '../../../Components/Card';

export default class DosGraph extends Component {
  constructor(props) {
    super(props);
    this.state = {
      listApi: { loading: false, error: false },
    };
  }
  render() {
    return (
      <>
        <Card>
          <CardHeader>
            <span>
              <h3>Do Adherence</h3>
              <span>From 19 April 2021 until 18 May 2021</span>
            </span>
          </CardHeader>
          <CardBody>
            <LineGraph
              data={this.props.data}
              firstValue={{ label: "Users Enrolled", value: "visits" }}
              secondValue={{ label: "Users Completed", value: "views" }}
            />
          </CardBody>
        </Card>
      </>
    );
  }
}
