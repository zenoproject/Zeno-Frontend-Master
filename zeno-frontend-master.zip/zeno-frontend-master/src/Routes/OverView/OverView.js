import React, { Component } from 'react';
import globel from '../../styles/globel/style.module.scss';
import ListOverView from './ListOverview';
import DosGraph from './DOsGraph';
import * as constants from './constants';
export default class Scedule extends Component {
  constructor(props) {
    super(props);
    this.state = {
      userList: '',
    };
  }
  render() {
    return (
      <>
        <article className={globel.contentBlock}>
          <ListOverView />
          <DosGraph data={constants.DUMMY_DATA} />
        </article>
      </>
    );
  }
}
