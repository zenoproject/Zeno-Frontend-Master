import Component from './OverView';
import { connect } from 'react-redux';
// import { listFiles } from '../../Redux/Actions';

function mapStateToProps(state) {
  return {};
}
function mapDispatchToProps(dispatch) {
  return {};
}
export default connect(mapStateToProps, mapDispatchToProps)(Component);
