/*eslint-disable*/
export const DUMMY_DATA = [
  {
    date: '2021-02-12T18:30:00.000Z',
    visits: 16.05,
    views: 8.707,
  },
  {
    date: '2021-02-13T18:30:00.000Z',
    visits: 15.96,
    views: 8.700,
  },
  {
    date: '2021-02-14T18:30:00.000Z',
    visits: 15.93,
    views: 8.701,
  },
  {
    date: '2021-02-15T18:30:00.000Z',
    visits: 15.87,
    views: 8.696,
  },
  {
    date: '2021-02-16T18:30:00.000Z',
    visits: 15.91,
    views: 8.704,
  },
  {
    date: '2021-02-17T18:30:00.000Z',
    visits: 15.86,
    views: 8.710,
  },
  {
    date: '2021-02-18T18:30:00.000Z',
    visits: 15.79,
    views: 8.719,
  },
  {
    date: '2021-02-19T18:30:00.000Z',
    visits: 15.73,
    views: 8.712,
  },
  {
    date: '2021-02-20T18:30:00.000Z',
    visits: 15.68,
    views: 8.718,
  },
  {
    date: '2021-02-21T18:30:00.000Z',
    visits: 15.65,
    views: 8.722,
  },
  {
    date: '2021-02-22T18:30:00.000Z',
    visits: 15.62,
    views: 8.730,
  },
  {
    date: '2021-02-23T18:30:00.000Z',
    visits: 15.67,
    views: 8.736,
  },
  {
    date: '2021-02-24T18:30:00.000Z',
    visits: 15.59,
    views: 8.742,
  },
  {
    date: '2021-02-25T18:30:00.000Z',
    visits: 15.67,
    views: 8.742,
  },
  {
    date: '2021-02-26T18:30:00.000Z',
    visits: 15.64,
    views: 8.733,
  },
];
