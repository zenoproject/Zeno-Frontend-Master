import React, { Component } from 'react';
import ListWrapper from '../../../Components/ListWrapper';
import FormBlock from '../../../Components/FormBlock';
import {
  Card,
  CardBody,
  CardFooter,
  CardHeader,
} from '../../../Components/Card';
import { Table } from 'antd';
import * as constants from './constants';

export default class ListOverView extends Component {
  constructor(props) {
    super(props);
    this.state = {
      list: [
        { value: 'user1', label: 'Jack Danel' },
        { value: 'user2', label: 'John' },
        { value: 'user3', label: 'Sammual' },
      ],
      listApi: { loading: false, error: false },
    };
  }
  render() {
    return (
      <>
        <Card>
          <CardHeader>
            <span>
              <h3>Do Statistics</h3>
              <span>From (Enter start date!) until 18 May 2021</span>
            </span>
            <div style={{ minWidth: '200px' }}>
              <FormBlock placeholder={'Search'} elementType='select' />
            </div>
          </CardHeader>
          <CardBody>
            <Table
              columns={constants.TABLE_CONFIG}
              dataSource={constants.DUMMY_TABLE_DATA}
              pagination={false}
              sorter={true}
            />
          </CardBody>
        </Card>
      </>
    );
  }
}
