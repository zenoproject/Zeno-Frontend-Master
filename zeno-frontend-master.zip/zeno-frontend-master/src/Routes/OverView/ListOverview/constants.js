import React, { Component } from 'react';
import SVGIcons from '../../../Components/SVGIcons';
export const TABLE_CONFIG = [
  {
    title: 'Category',
    dataIndex: 'category',
    sorter: (a, b) => a.category.length - b.category.length,
    sortDirections: ['descend', 'ascend'],
  },
  {
    title: 'Title',
    dataIndex: 'title',
    sorter: (a, b) => a.title.length - b.title.length,
    sortDirections: ['descend', 'ascend'],
  },
  {
    title: 'Sent',
    dataIndex: 'sent',
    sorter: (a, b) => a.sent.length - b.sent.length,
    sortDirections: ['descend', 'ascend'],
  },
  {
    title: 'Completed',
    dataIndex: 'completed',
    sorter: (a, b) => a.completed.length - b.sent.length,
    sortDirections: ['descend', 'ascend'],
  },
  {
    title: () => {
      return <SVGIcons type='SVG-smiley-sad' />;
    },
    dataIndex: 'valueOne',
  },
  {
    title: () => <SVGIcons type='SVG-smiley-sad' />,
    dataIndex: 'valueTwo',
  },
  {
    title: () => <SVGIcons type='SVG-smiley-neutral' />,
    dataIndex: 'valueThree',
  },
  {
    title: () => <SVGIcons type='SVG-smiley-happy' />,
    dataIndex: 'valueFour',
  },
];

export const DUMMY_TABLE_DATA = [
  {
    category: 'Starter',
    title: 'New Way Day ',
    sent: '20',
    completed: '10',
    valueOne: '1.7',
    valueTwo: '1',
    valueThree: '1',
    valueFour: '8',
  },
];
