Steps to run the Front end:

1. Clone the repo.
2. Run ' npm i ' in command line
3. Run 'npm i @amcharts/amcharts4' in command line
4. Run 'npm start' to run in debug mode.
5. To run in pm2 'pm2 start npm --name "zeno_frontend" -- start'
